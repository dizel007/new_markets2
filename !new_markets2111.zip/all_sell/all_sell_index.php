<?php
$offset = "../";
require_once $offset.'connect_db.php';
require_once $offset.'pdo_functions/pdo_functions.php';

require_once $offset."mp_functions/ozon_api_functions.php";
require_once $offset."mp_functions/ozon_functions.php";
require_once $offset."mp_functions/wb_api_functions.php";
require_once $offset."mp_functions/wb_functions.php";
require_once $offset."mp_functions/yandex_api_functions.php";
require_once $offset."mp_functions/yandex_functions.php";

require_once "functions/all_sell_functions.php";

echo '<link rel="stylesheet" href="css/sell_table.css">';

echo "<pre>";
    // die();
 insert_in_table_user_action($pdo, $userdata['user_login'] , 'OPEN_SELL_TABLE');



// Доставем информацию по складам ****** АКТИВНЫМ СКЛАДАМ ******
$sklads = select_info_about_sklads($pdo); // ОБщая Информация по складам

$arr_need_ostatok = get_min_ostatok_tovarov($pdo); // массив с утвержденным неснижаемым остатком

// Вся продаваемая номенклатура
// $arr_all_nomenklatura = select_all_nomenklaturu($pdo);
$arr_all_nomenklatura = select_active_nomenklaturu($pdo);

// echo "<ore>";
// print_r($arr_all_nomenklatura);


// Названия магазинов
$wb_anmaks = 'wb_anmaks';
$wb_ip = 'wb_ip_zel';
$ozon_anmaks = 'ozon_anmaks';
$ozon_ip = 'ozon_ip_zel';
$yandex_anmaks_fbs = 'ya_anmaks_fbs';

// Формируем каталоги товаров
$wb_catalog      = get_catalog_tovarov_v_mp($wb_anmaks ,        $pdo, 'all');
$wbip_catalog    = get_catalog_tovarov_v_mp($wb_ip,             $pdo, 'all'); // фомируем каталог
$ozon_catalog    = get_catalog_tovarov_v_mp($ozon_anmaks,       $pdo ,'all'); // получаем озон каталог
$ozon_ip_catalog = get_catalog_tovarov_v_mp($ozon_ip,           $pdo, 'all'); // получаем озон каталог
$ya_fbs_catalog  = get_catalog_tovarov_v_mp($yandex_anmaks_fbs, $pdo, 'all'); // получаем yandex каталог

// Формируем массив в номенклатурой, с учетом того, что один товар можнт продаваться под разным артикулом на Маркете

/******************************      Получаем Фактические остатки с ВБ *****************************/
$wb_catalog = get_ostatki_wb ($token_wb, $wb_catalog, $sklads[$wb_anmaks ]['warehouseId']);
//    Достаем фактически заказанные товары  *****************************
$wb_catalog = get_new_zakazi_wb ($token_wb, $wb_catalog);

/* *****************************      Получаем Фактические остатки с ВБ ИП *****************************/
$wbip_catalog = get_ostatki_wb ($token_wb_ip, $wbip_catalog, $sklads[$wb_ip]['warehouseId']); // цепляем остатки 
//    Достаем фактически заказанные товары  WB IP *****************************
$wbip_catalog = get_new_zakazi_wb ($token_wb_ip, $wbip_catalog);

//***************************** Получаем Фактические остатки с OZON *****************************
$ozon_catalog = get_ostatki_ozon ($token_ozon, $client_id_ozon, $ozon_catalog); // цепояем остатки
//   Достаем фактически заказанные товары OZON *****************************
$ozon_catalog = get_new_zakazi_ozon ($token_ozon, $client_id_ozon, $ozon_catalog); // цепляем продажи

//***************************** Получаем Фактические остатки с OZON *****************************
$ozon_ip_catalog = get_ostatki_ozon ($token_ozon_ip, $client_id_ozon_ip, $ozon_ip_catalog); // цепояем остатки
//   Достаем фактически заказанные товары OZON *****************************
$ozon_ip_catalog = get_new_zakazi_ozon ($token_ozon_ip, $client_id_ozon_ip, $ozon_ip_catalog); // цепляем продажи

//*****************************  получаем массив (артикул - кол-во проданного товара  *****************************

//***************************** Получаем Фактические остатки с ЯНДЕКС *****************************
$ya_fbs_catalog = get_ostatki_yandex ($yam_token, $campaignId_FBS, $ya_fbs_catalog); // цепояем остатки
//*****************************  Достаем фактически заказанные товары YANDEX *****************************
$ya_fbs_catalog = get_new_zakazi_yandex ($yam_token, $campaignId_FBS, $ya_fbs_catalog); // цепляем продажи



// echo "<pre>";
// print_r ($wb_catalog);
// die();


print_info_sell_market ($arr_all_nomenklatura, $wb_catalog, $wbip_catalog, $ozon_catalog , $ozon_ip_catalog, $ya_fbs_catalog);

// print_r($ya_fbs_catalog);
/**************************************************************************************
 ********************************** THE END **********************************************
 *****************************************************************************************/

 // Формируем каталог проданных товаров по магащинам
$summ_sell_arr[$wb_anmaks] = add_sells_in_sum_array ($wb_catalog) ;
$summ_sell_arr[$wb_ip] = add_sells_in_sum_array ($wbip_catalog) ;
$summ_sell_arr[$ozon_anmaks] = add_sells_in_sum_array ($ozon_catalog) ;
$summ_sell_arr[$ozon_ip] = add_sells_in_sum_array ($ozon_ip_catalog) ;
$summ_sell_arr[$yandex_anmaks_fbs] = add_sells_in_sum_array ($ya_fbs_catalog) ;

echo "<pre>";
print_r ($summ_sell_arr);
// die();
$send_data = json_encode($summ_sell_arr,  JSON_HEX_APOS | JSON_HEX_QUOT);
echo "<br>";


echo <<<HTML

<form method="POST" action="fbs_sell_in_db.php">
    <input type="hidden" name="send_data" value=$send_data>
    
    <button type="submit">Отправить Данные в БД(ТОЛЬКО ПЕРЕД РАЗБОРОМ)</button>
</form>
HTML;

die('');


function add_sells_in_sum_array ($mp_catalog) {
   foreach ($mp_catalog as $select_shop) {
    if (isset( $select_shop['sell_count'])){
        $sell_arr[mb_strtolower($select_shop['main_article'])] = @$sell_arr[mb_strtolower($select_shop['main_article'])] + $select_shop['sell_count'];
    }
} 

return $sell_arr ?? false;
}