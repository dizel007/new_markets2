<?php


$client_id = "43209969-1729849782881@advertising.performance.ozon.ru"; 
              
$client_secret = "6k6SRW1S5lhUAN7GzcIhug8FFnU0tTGTNP_8mpqn2KN4ojFZYvn04nq2lfg99kfwt0XJ6lsiFfss6VytrA";
              