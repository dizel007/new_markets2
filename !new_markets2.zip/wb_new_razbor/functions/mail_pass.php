<?php

$mail_Username = 'noboby@ow2.ru';             // Наш логин
$mail_Password = 'aKcMl82LWAUoIOC9';                 // Наш пароль от ящика