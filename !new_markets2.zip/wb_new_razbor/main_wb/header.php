<?php

echo <<<HTML
<html>


<head>
<link rel="stylesheet" href="css/main_wb.css">
<script type="text/javascript" src="../js/js_hide_button.js"></script>
</head>

<body>
    
HTML;

