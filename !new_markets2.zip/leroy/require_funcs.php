<?php

require_once "functions/functions.php";
require_once "functions/art_cat.php";
require_once "controller/create_spisok.php"; // отрисовывает список товаров
