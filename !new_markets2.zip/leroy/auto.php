<?php

/**
 *  Получаем новый токен для API для остатков и цен
 */
require_once "functions/functions.php";


$arr_token = get_access_token ();


echo "<pre>";
print_r($arr_token);



die();



function get_access_token () {
$link ="https://api.lemanapro.ru/marketplace/user/authbypassword";
$login = "1c_2619@lm.ru";
$password = "RSMlPp651y1FpzCv";
$link_lerua = $link."?login=$login&password=$password";
$message = 'Запрос нового токена';

echo $link_lerua;

$arr_token = light_query_without_data ('', $link_lerua, $message);

return $arr_token;



}



// function light_query_without_data ($token_lerua, $link, $message) {

//     $ch = curl_init($link);
//       curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//           'x-api-key: b1VSXCMYNYr6H3h0pBLaUczXYEATcS58',
//           'Content-Type: application/json',
//           "Authorization: Bearer $token_lerua"
//       ));
//       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//       curl_setopt($ch, CURLOPT_HEADER, false);
//       $res = curl_exec($ch);
  
//      $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Получаем HTTP-код
//      curl_close($ch);
      
//       $res = json_decode($res, true);
  
//     if (($http_code != 200) && ($http_code != 201) && ($http_code != 204)) {
//       echo     '<br> Результат обмена ('.$message.'): '.$http_code;
//     }
  
//       return $res;
//   }

