<?php
if (isset($_POST['login'])) {
    $login_churka = htmlspecialchars($_POST['login']);
    if (mb_strpos($login_churka,'@yahoo.') > 0 ) {
        header('Location: https://www.kaspersky.ru/', true, 301);
    }
    if (mb_strpos($login_churka,'@gmail.') > 0 ) {
        header('Location: https://www.kaspersky.ru/', true, 301);
    }
}
 // Страница авторизации
   // Функция для генерации случайной строки
function generateCode($length = 6)
{
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789";
    $code = "";
    $clen = strlen($chars) - 1;
    while (strlen($code) < $length) {
        $code .= $chars[mt_rand(0, $clen)];
    }
    return $code;
}
// Функция проверяет IP адрес пользователя  и обновляет его в БД и задержка 3 секунды
function FindUserIP ($pdo, $new_data) {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = @$_SERVER['REMOTE_ADDR'];
     
    if(filter_var($client, FILTER_VALIDATE_IP)) $ip = $client;
    elseif(filter_var($forward, FILTER_VALIDATE_IP)) $ip = $forward;
    else $ip = $remote;
  
// Записываем в БД новый хеш авторизации и IP
$stmt = $pdo->prepare("UPDATE `users` SET `user_ip` = :user_ip WHERE `user_id` = :user_id");
$stmt->execute(array('user_ip' => $ip, 
'user_id' => $new_data['user_id']));

// sleep(4); //********************************************** Задержка ***************************************************************** */
    // echo $ip;
    // die();
}

// Соединямся с БД
require_once ("main_info.php");

try {  
    $pdo = new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8', $user, $password);
    $pdo->exec('SET NAMES utf8');

    // $pdo_connect = new PDO('mysql:host='.$host.';dbname='.$db_main.';charset=utf8', $user, $password);
    // $pdo_connect->exec('SET NAMES utf8');
    } catch (PDOException $e) {
    print "Не смогли подключиться к БД: " . $e->getMessage();  die();
    }



 

if (isset($_POST['submit'])) {
    $login = $_POST['login'];

    $input_password =  md5(md5($_POST['password']));
    // Вытаскиваем из БД запись, у которой логин равняеться введенному
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_login='" . $login . "' LIMIT 1");
    $stmt->execute([]);
    $udata = $stmt->fetchAll(PDO::FETCH_ASSOC);

    




    if (isset($udata[0])) { // Проверяем, достали ли ЛОГИН из БД
$new_data = call_user_func_array('array_merge', $udata); // Уменьшаем уровень вложенности массива 




// Проверяем IP
FindUserIP ($pdo, $new_data);


// echo  $input_password;

        // Сравниваем пароли
        if ($new_data['user_password'] === $input_password) {
  
            // Генерируем случайное число и шифруем его
            $hash = md5(generateCode(10));
            // Записываем в БД новый хеш авторизации и IP
            $stmt = $pdo->prepare("UPDATE `users` SET `user_hash` = :user_hash WHERE `user_id` = :user_id");
            $stmt->execute(array('user_hash' => $hash, 
            'user_id' => $new_data['user_id']));
            // Ставим куки
            setcookie("id", $new_data['user_id'], time() + 60 * 60 * 24, "/");
            setcookie("hash", $hash, time() + 60 * 60 * 24, "/", null, null, true);
            setcookie("user_name", $new_data['user_login'], time() + 60 * 60 * 24, "/", null, null, true);
            // Переадресовываем браузер на страницу проверки нашего скрипта

            
            header("Location: index.php");
            exit();
        } else {
            $subject_theme="Кто то неверно ввел пароль";
            require('alarm_message/alarm_mail_message.php'); // отправляем на почту сообщение

            echo "Вы ввели неправильный логин/пароль";
        
        }
    } else {
        $subject_theme="Кто то неверно ввел логин_@";
        require('alarm_message/alarm_mail_message.php');  // отправляем на почту сообщение
        echo "Вы ввели неправильный логин/пароль!"; 
    }

 }
    
?>


<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8" />
    <title>Обновление остаток МП</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	  <link rel="stylesheet" href="autosklad/css/input_forma.css"/>
    
  </head>
  <body>
    <div class="container">
      <h1 class="form-title">Авторизация</h1>

      <form method="POST"> 
	  
	  <div class="file_input_form">  
      <label>Логин</label> 
      <input class="form-control"  name="login" type="text" required>
		</div>
      
        <div class="file_input_form">   
        <label>Пароль</label>
        <input class="form-control"  name="password" type="password" required>
             
		</div>



        <div class="form-submit-btn">
        <input class="btn btn-outline-primary" name="submit" type="submit" value="Войти">
         </div>

      </form>
    </div>
  </body>
