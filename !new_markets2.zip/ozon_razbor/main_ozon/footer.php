<?php



echo <<<HTML

</body>
</html>



HTML;