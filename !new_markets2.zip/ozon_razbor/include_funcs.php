<?php

// require_once 'functions/torpen.php';
require_once "functions/functions.php"; // используемые функции
require_once "functions/functions_sticker.php"; // функции для стикеров 
require_once "functions/create_table_spisok.php"; // используемые функции
require_once 'functions/make_zakaz_new.php';
// require_once 'functions/make_all_etiketki.php';





